migrate((app) => {
  let collection;
  try {
    collection = app.findCollectionByNameOrId('contact_messages');
  } catch (_) {
    collection = new Collection({
      name: 'contact_messages',
      type: 'base',
      listRule: null,
      viewRule: null,
      createRule: '@request.body.consent = true',
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'name', type: 'text', required: true, min: 2, max: 120 },
        { name: 'email', type: 'email', required: true },
        { name: 'message', type: 'text', required: true, min: 10, max: 5000 },
        { name: 'consent', type: 'bool', required: true },
        { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
    });
    app.save(collection);
  }
}, (app) => {
  const collection = app.findCollectionByNameOrId('contact_messages');
  app.delete(collection);
});
