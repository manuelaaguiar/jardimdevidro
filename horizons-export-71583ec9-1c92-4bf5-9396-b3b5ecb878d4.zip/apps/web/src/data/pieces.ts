export type Piece = {
  key: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  editorial: string;
  editorialAlt: string;
};

export const pieces: Piece[] = [
  {
    key: 'margaridas',
    number: '01',
    title: 'Margaridas',
    subtitle: 'A delicadeza em flor.',
    description: 'Pétalas brancas e centros dourados. Um jardim delicado que acompanha a transparência do vidro.',
    editorial: 'https://vgbujcuwptvheqijyjbe.supabase.co/storage/v1/object/public/hmac-uploads/projects/13ddaf01-213e-4e19-9b1f-1a3bf55eb55f/content-assets/editorial-margaridas/margaridas.jpg',
    editorialAlt: 'Ambientação editorial de uma taça de vinho pintada à mão com margaridas brancas e folhas verdes, sobre pedra e linho.',
  },
  {
    key: 'floral',
    number: '02',
    title: 'Floral em tons quentes',
    subtitle: 'Quando a cor se acende.',
    description: 'Vermelho, laranja e amarelo se encontram em pinceladas expressivas, com pequenos toques de verde.',
    editorial: 'https://vgbujcuwptvheqijyjbe.supabase.co/storage/v1/object/public/hmac-uploads/projects/13ddaf01-213e-4e19-9b1f-1a3bf55eb55f/content-assets/editorial-floral/floral.jpg',
    editorialAlt: 'Ambientação editorial de uma taça pintada à mão com uma flor em vermelho, laranja e amarelo.',
  },
  {
    key: 'folhas',
    number: '03',
    title: 'Folhas no vidro',
    subtitle: 'Leveza em cada ramo.',
    description: 'Folhas verdes e tons suaves desenham um encontro entre a natureza e a forma da taça.',
    editorial: 'https://vgbujcuwptvheqijyjbe.supabase.co/storage/v1/object/public/hmac-uploads/projects/13ddaf01-213e-4e19-9b1f-1a3bf55eb55f/content-assets/editorial-folhas/folhas.jpg',
    editorialAlt: 'Ambientação editorial de uma taça martini pintada à mão com ramos e folhas em verde e dourado.',
  },
  {
    key: 'botanico',
    number: '04',
    title: 'Composição botânica',
    subtitle: 'Outras formas de florescer.',
    description: 'Folhas em tons de lavanda e violeta, formas orgânicas e detalhes dourados sobre um fundo claro.',
    editorial: 'https://vgbujcuwptvheqijyjbe.supabase.co/storage/v1/object/public/hmac-uploads/projects/13ddaf01-213e-4e19-9b1f-1a3bf55eb55f/content-assets/editorial-botanico/botanico.jpg',
    editorialAlt: 'Ambientação editorial de um pote de vidro pintado à mão com folhas violeta, formas orgânicas e um círculo dourado.',
  },
];

export const heroImage = pieces[1].editorial;
