import type { Route } from './+types/home';
import { seo, absoluteUrl, siteOriginFrom } from '@/lib/seo';
import { Hero } from '@/components/home/hero';
import { Values } from '@/components/home/values';
import { Gallery } from '@/components/home/gallery';
import { Artist } from '@/components/home/artist';
import { heroImage } from '@/data/pieces';

const CANONICAL = 'https://jardimdevidro.com/';

export function meta({ matches, location }: Route.MetaArgs) {
  const origin = siteOriginFrom(matches);
  return seo({ matches, location }, {
    title: 'Jardim de Vidro — Ateliê Ilma Gomes',
    description: 'Portfólio artístico de Ilma Gomes: quatro peças de vidro pintadas à mão e a história do ateliê Jardim de Vidro.',
    path: 'https://jardimdevidro.com/',
    image: heroImage,
    jsonLd: [
      {
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        name: 'Jardim de Vidro — Ateliê Ilma Gomes',
        url: CANONICAL,
        description: 'Peças de vidro pintadas à mão por Ilma Gomes. A natureza em cada traço.',
        inLanguage: 'pt-BR',
      },
      {
        '@context': 'https://schema.org',
        '@type': 'Person',
        name: 'Ilma Gomes',
        url: CANONICAL,
        jobTitle: 'Artista de pintura em vidro',
        worksFor: { '@type': 'Organization', name: 'Jardim de Vidro Ateliê Ilma Gomes', url: CANONICAL },
        image: absoluteUrl(origin || CANONICAL, heroImage),
      },
    ],
  });
}

export default function HomePage() {
  return (
    <main>
      <Hero />
      <Values />
      <Gallery />
      <Artist />
    </main>
  );
}
