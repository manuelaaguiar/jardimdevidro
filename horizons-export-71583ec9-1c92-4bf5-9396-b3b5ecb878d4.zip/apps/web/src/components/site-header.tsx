import { useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  { href: '/#pecas', label: 'As peças' },
  { href: '/#artista', label: 'A artista' },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <a className="wordmark" href="/#inicio" aria-label="Jardim de Vidro, Ateliê Ilma Gomes — início">
        <span className="wordmark-name">Jardim de Vidro</span>
        <span className="wordmark-sub">Ateliê Ilma Gomes</span>
      </a>
      <nav className="desktop-nav" aria-label="Navegação principal">
        {links.map(link => (
          <a key={link.href} href={link.href}>{link.label}</a>
        ))}
      </nav>
      <button
        className="menu-button"
        type="button"
        aria-expanded={open}
        aria-controls="mobile-navigation"
        onClick={() => setOpen(value => !value)}
      >
        {open ? <X size={22} strokeWidth={1.4} /> : <Menu size={22} strokeWidth={1.4} />}
        <span className="sr-only">{open ? 'Fechar menu' : 'Abrir menu'}</span>
      </button>
      {open ? (
        <nav id="mobile-navigation" className="mobile-nav" aria-label="Navegação móvel">
          {links.map(link => (
            <a key={link.href} href={link.href} onClick={() => setOpen(false)}>{link.label}</a>
          ))}
        </nav>
      ) : null}
    </header>
  );
}
