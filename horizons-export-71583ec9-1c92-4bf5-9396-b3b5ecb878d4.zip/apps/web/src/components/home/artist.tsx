export function Artist() {
  return (
    <section className="artist" id="artista" aria-labelledby="artist-title">
      <div className="artist-inner">
        <div>
          <p className="kicker kicker-light">As mãos por trás do jardim</p>
          <h2 id="artist-title">Ilma Gomes. A arte do cuidado.</h2>
          <p className="signature">Ilma Gomes</p>
        </div>
        <div className="artist-copy">
          <p>O que começou como um passatempo em casa, após a aposentadoria, revelou um talento: transformar o vidro em pequenos jardins.</p>
          <p>Ilma encontrou na pintura floral uma forma de expressar o que também está nos seus gestos: carinho, delicadeza e afeto. As pinceladas guardam essa presença humana, com a singularidade de um trabalho feito à mão.</p>
          <p className="artist-aside">Sofisticação sem ostentação. Beleza com presença.</p>
        </div>
      </div>
    </section>
  );
}
