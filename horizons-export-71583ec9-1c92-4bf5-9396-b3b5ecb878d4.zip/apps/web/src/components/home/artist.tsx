export function Artist() {
  return (
    <section className="artist" id="artista" aria-labelledby="artist-title">
      <div className="artist-inner">
        <div>
          <p className="kicker kicker-light">As mãos por trás do jardim</p>
          <h2 id="artist-title">Ilma Gomes. A arte do cuidado.</h2>
          <p className="signature">Ilma Gomes</p>
        </div>
        <div className="artist-copy">
          <p>Há dons que florescem no seu próprio tempo.<br />Da pintura em vidro, nasceu um jardim feito de afeto.</p>
          <p>Ilma encontrou na pintura floral uma forma de expressar o que também está nos seus gestos: carinho e delicadeza.</p>
          <p>Em cada pincelada, a beleza da presença humana.<br />Em cada jardim, a assinatura da sua singularidade.</p>
          <p className="artist-aside">Sofisticação sem ostentação. Beleza com presença.</p>
        </div>
      </div>
    </section>
  );
}
