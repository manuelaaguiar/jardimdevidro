import { ArrowDown } from 'lucide-react';
import { heroImage } from '@/data/pieces';

export function Hero() {
  return (
    <section className="hero" id="inicio" aria-labelledby="hero-title">
      <div className="hero-copy">
        <div className="seal" aria-hidden="true">
          <img className="seal-img" src="/seal.webp" width={1000} height={1000} alt="" />
        </div>
        <p className="kicker">Natureza · Arte · Afeto</p>
        <h1 id="hero-title">Mais do que taças, <em>histórias.</em></h1>
        <p className="lede">Peças de vidro pintadas à mão por Ilma Gomes. A natureza em cada traço. O cuidado em cada detalhe.</p>
        <a className="text-cta" href="#pecas">Conheça as quatro peças <ArrowDown size={16} strokeWidth={1.4} aria-hidden="true" /></a>
      </div>
      <figure className="hero-figure">
        <img
          src={heroImage}
          width={1200}
          height={1500}
          alt="Taça de vidro pintada à mão com uma flor em vermelho, laranja e amarelo, sobre pedra clara e linho. Ambientação editorial da peça Floral em tons quentes."
          fetchPriority="high"
        />
        <figcaption>Arte que floresce em cada momento</figcaption>
      </figure>
    </section>
  );
}
