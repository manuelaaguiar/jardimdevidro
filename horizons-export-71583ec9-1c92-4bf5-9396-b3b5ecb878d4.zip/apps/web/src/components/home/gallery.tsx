import { useRef, useState } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { ArrowLeft, ArrowRight, X } from 'lucide-react';
import { pieces } from '@/data/pieces';

export function Gallery() {
  const [viewer, setViewer] = useState<number | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);

  const open = (index: number, button: HTMLButtonElement) => {
    triggerRef.current = button;
    setViewer(index);
  };
  const close = () => setViewer(null);

  const piece = viewer !== null ? pieces[viewer] : null;

  return (
    <section className="gallery" id="pecas" aria-labelledby="gallery-title">
      <div className="gallery-intro">
        <div>
          <p className="kicker">O jardim · 4 peças em destaque</p>
          <h2 id="gallery-title">Beleza que se revela de perto.</h2>
        </div>
        <p>Vidro, cor e gestos singulares. Toque em cada peça para conhecer os detalhes em ampliação.</p>
      </div>
      <div className="piece-grid">
        {pieces.map((item, index) => (
          <article key={item.key} className="piece">
            <div className="piece-frame">
              <img src={item.editorial} width={900} height={1125} alt={item.editorialAlt} loading="lazy" />
              <button type="button" className="enlarge" aria-label={`Ampliar ${item.title}`} onClick={(event) => open(index, event.currentTarget)}>
                Ampliar <ArrowRight size={14} strokeWidth={1.5} aria-hidden="true" />
              </button>
            </div>
            <div className="piece-heading">
              <span>{item.number}</span>
              <h3>{item.title}</h3>
            </div>
            <p className="piece-sub">{item.subtitle}</p>
          </article>
        ))}
      </div>
      <p className="gallery-note">Ambientações criadas com auxílio de IA a partir das peças de Ilma Gomes.</p>

      <Dialog.Root open={viewer !== null} onOpenChange={isOpen => { if (!isOpen) close(); }}>
        <Dialog.Portal>
          <Dialog.Overlay className="viewer-backdrop" />
          <Dialog.Content
            className="viewer-panel"
            aria-describedby="viewer-note"
            onCloseAutoFocus={(event) => {
              event.preventDefault();
              triggerRef.current?.focus();
              triggerRef.current = null;
            }}
            onKeyDown={event => {
              if (viewer === null) return;
              if (event.key === 'ArrowRight') setViewer((viewer + 1) % pieces.length);
              if (event.key === 'ArrowLeft') setViewer((viewer + pieces.length - 1) % pieces.length);
            }}
          >
            <div className="viewer-toolbar">
              <Dialog.Title className="viewer-title">{piece?.title ?? 'Peça'}</Dialog.Title>
              <Dialog.Close className="icon-button">
                <X size={20} strokeWidth={1.5} aria-hidden="true" />
                <span className="sr-only">Fechar</span>
              </Dialog.Close>
            </div>
            {piece ? <img className="viewer-photo" src={piece.editorial} alt={piece.editorialAlt} /> : null}
            <p id="viewer-note" className="viewer-note">{piece?.description}</p>
            <div className="viewer-nav">
              <button type="button" className="icon-button" aria-label="Peça anterior" onClick={() => viewer !== null && setViewer((viewer + pieces.length - 1) % pieces.length)}>
                <ArrowLeft size={20} strokeWidth={1.4} aria-hidden="true" />
              </button>
              <span>{piece?.number ?? '01'} / 04</span>
              <button type="button" className="icon-button" aria-label="Próxima peça" onClick={() => viewer !== null && setViewer((viewer + 1) % pieces.length)}>
                <ArrowRight size={20} strokeWidth={1.4} aria-hidden="true" />
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </section>
  );
}
