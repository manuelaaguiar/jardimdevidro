const values = ['Exclusividade', 'Carinho', 'Delicadeza', 'Cuidado', 'Afeto'];

export function Values() {
  return (
    <section className="values" aria-label="Valores do ateliê">
      <ul>
        {values.map(value => (
          <li key={value}>{value}</li>
        ))}
      </ul>
    </section>
  );
}
