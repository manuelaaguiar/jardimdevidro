import { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';

export function SiteFooter() {
  const [feedback, setFeedback] = useState('');

  const share = async () => {
    const url = 'https://jardimdevidro.com/';
    const payload = { title: 'Jardim de Vidro — Ateliê Ilma Gomes', text: 'Natureza, arte e bons encontros.', url };
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      try {
        await navigator.share(payload);
        setFeedback('Compartilhamento aberto no dispositivo.');
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(url);
      setFeedback('Link copiado: jardimdevidro.com');
    } catch {
      setFeedback('Não foi possível copiar o link. O endereço é jardimdevidro.com');
    }
  };

  return (
    <footer className="site-footer">
      <p className="footer-line">Natureza, arte e bons encontros.</p>
      <p className="footer-brand">Jardim de Vidro · Ateliê Ilma Gomes</p>
      <button type="button" className="share-button" onClick={share}>
        Compartilhar o jardim <ArrowUpRight size={15} strokeWidth={1.4} aria-hidden="true" />
      </button>
      <p className="share-feedback" role="status" aria-live="polite">{feedback}</p>
      <p className="footer-copy">© 2026 Jardim de Vidro Ateliê Ilma Gomes</p>
    </footer>
  );
}
